import { config } from 'dotenv';
config();

import '@/ai/flows/supplemental-education.ts';